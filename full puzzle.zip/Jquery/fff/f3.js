 $(document).ready(function() {

   var pane = $('#Container'),
     player = $('#PLayer'),
     shuriken = $("#Shuriken"),
     w = pane.width() - player.width(),
     d = {},
     timer = 0,
     enemygid = 0,
     timerInterval,
     Shurikengid = 0,
     x = 3;

   $("#Start").click(function() {
     $(this).attr('disabled', 'disabled');
     startTimer();
     ReleaseEnemies()
   });



   function startTimer() {

     timerInterval = setInterval(function() {
       $("#Time").html(timer++);
     }, 1000);


   }

   //            setTimeout(function () {
   //                 EndGame();
   //            }, 2000);

   function EndGame() {
     timer = 0;
     clearInterval(timerInterval);
     $("#Time").html("The Game has ended");
   }

   function newv(v, a, b) {
     var n = parseInt(v, 10) - (d[a] ? x : 0) + (d[b] ? x : 0);

     return n < 0 ? 0 : n > w ? w : n;
   }

   function s4() {
     return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
   };

   function guid() {
     return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
   }

   function CreateChuriken() {
     Shurikengid = guid();
     var shuriken = document.createElement('img');
     shuriken.src = 'http://fc01.deviantart.net/fs41/f/2009/035/a/5/Ninja_star_dock_icon__K_ninja__by_piepiepie12345667890.png';
     shuriken.id = "Shuriken" + Shurikengid;
     shuriken.className = 'Shuriken';
     player.append(shuriken);
   }


   $(window).keypress(function(e) {
     if (e.which == 32) {
       CreateChuriken();
       $("#Shuriken" + Shurikengid).animate({
         left: '+=300px'
       }, {
         duration: 'slow',
         progress: function() {

           $('.Shuriken').each(function() {
             var sOffset = $(this).offset();
             $('.Enemy').each(function() {
               var eOffset = $(this).offset();
               if (Math.floor(eOffset.left / 10) == Math.floor(sOffset.left / 10)) {
                 alert("boom!");
               }
             })
           });
         }
       })
     }
   });



   $(window).keydown(function(e) {
     d[e.which] = true;
   });
   $(window).keyup(function(e) {
     d[e.which] = false;
   });

   setInterval(function() {
     player.css({
       top: function(i, v) {
         return newv(v, 38, 40);
       }
     });
   }, 20);


   function ReleaseEnemies() {
     var x = setInterval(function() {
       CreateAndAnimateEnemyImg();
     }, 3000);

     setTimeout(function() {
       clearInterval(x);
     }, 1000 * 60);

   }

   function CreateAndAnimateEnemyImg() {
     var nh = Math.floor((Math.random() * 267) + 1);
     enemygid = guid();
     var enemy = document.createElement('img');
     enemy.src = 'https://lh3.ggpht.com/-iWPbpjo8tbo/TzTaJ25rytI/AAAAAAAAAto/aS2zrzm-w_o/s1600/ninja.png';
     enemy.className = 'Enemy';
     enemy.id = 'enemy' + enemygid;
     enemy.style.top = -30 + 'px';
     pane.append(enemy);
     enemy.onload = function() {
       setInterval(function() {
         $('.Enemy').animate({
           'left': '-=20px'
         });
       }, 200);

     }
   }

 });
