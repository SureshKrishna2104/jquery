 $(function() {





var galleryItems=$(".gallery").find("img");
galleryItems.css("width","33%").css("opacity","0.7");
galleryItems.mouseenter(function(){
  $(this).stop().fadeTo(500,1);
});

galleryItems.mouseleave(function(){
  $(this).stop().fadeTo(500,0.7);
});
$("html").keydown(function(event){
console.log(event.which);
});
var Arr_right=39;
$("html").keydown(function(event){
  if(event.which == Arr_right){
    $(".green-box").stop().animate({
    marginLeft:"+=10px"
    },50);
  }

});
var Arr_left=37;
$("html").keydown(function(event){
  if(event.which == Arr_left){
    $(".green-box").stop().animate({
    marginRight:"+=10px"
    },50);
  }


//mousehandler
$("#btn-click").click({ 
  user:"Suresh",
  domain:"Cricket"
},function(event){
  greetUser(event.data);

	//alert("button clicked");

});


function greetUser(userdata){
  username=userdata.user || "Anonymous";
  domain=userdata.domain || "example.com";
  alert("Welcome back"+username+"from"+domain+"!");

}



$(".blue-box").click(function(){
	$(this).fadeTo("5000","0.5");
});
var b=$(".blue-box");
b.mouseenter(function(){
	$(this).stop().fadeTo(500,0.5);
});

b.mouseleave(function(){
	$(this).stop().fadeTo(500,1);
});
$("html").on("click keydown",function(){
console.log("Mouse was clicked or key was pressed.");
});

$("p").click(function(){
$(this).slideUp();
});




$("p").mouseenter(function(){
  $(this).css("fontSize","30px");
   $(this).mouseleave(function(){
     $(this).css("fontSize","19px");
   });
});

  // jQuery goes here...

  // Uncomment this line to fade out the red box on page load
   //$(".red-box").fadeTo(3000, 0.2);
   //".red-box").fadeOut(2000);
   //$(".green-box").fadeOut(2000);

   //$(".green-box").fadeTo(2000, 0.67);
  
  
   //$(".blue-box").slideUp(1000);
   // $(".blue-box").fadeOut(1000);
    //$(".blue-box").fadeIn(2000);
    //$(".green-box").fadeTo(2000,0.5);
    //$("p").hide();
    // $("p").show(1000);
     //$("p").slideUp(1000);
      //$("p").slideDown(1000);
      $(function(){
      	$(".red-box").hide();
      	var bluebox=$(".blue-box");
      	console.log(bluebox.css("width"));
      	console.log($("p").css(["fontSize"]));
      	$("p").css("fontSize","20px");
      	console.log($("p").css(["fontSize"]));
     // var galleryimage=$(".gallery").find("img").first();
     
      var images=[
      "images/laptop-mobile_small.jpg",
      "images/laptop-on-table_small.jpg",
      "images/people-office-group-team_small.jpg"];

      //var gallery=$(".gallery");
      //gallery.data("availableImages",images);
     // console.log(gallery.data("availableImages"));
    
      //var para=$("p:first");
     // para.html("<strong>i am just appending</strong>");



   /* var i=0;
    $(".gallery").find("img").on("click",function(){
     i=(i+1)%images.length;
     $(this).fadeOut(function(){
    $(this).attr("src",images[i].fadeIn);
     });
    });*/
     /*setInterval(function(){
     	i=(i+1)%images.length;
     	//console.log(i);




     	galleryimage.fadeOut(function(){
        $(this).attr("src",images[i]);
        $(this).fadeIn();
     	});
        //console.log(galleryimage.attr("src"));
     },2000);*/


       });

      $(function() {
      	//$(".red-box, .blue-box").replacewith
      	//$("<div class='green-box'>Moreblue</div>").replaceAll(".red-box, .blue-box");
      //$(".red-box").after(function() {
      	//return "<div class='blue-box' >blue2</div>";
     // });
    
       var a=$("#lin");
       console.log(a.attr("href"));
       console.log(a.attr("title"));
       a.attr("href","http://youtube.com")
    
       var checkbox=$("input:checkbox");
       console.log(checkbox.prop("checked"));
       console.log(checkbox.attr("checked"));
      

      var input=$("input:text");
      console.log(input.val());

     // $(".green-box").after ($(".red-box"));
    // $(".red-box").attr("width","180px");
  });
      $(function(){
     $("p").css("fontStyle","TimesNewRoman");
    // $("input[type='text']").css("background-Color","red");
     $("input[type='password']").css("background-Color","blue");
     $("input:text").css("font-weight","bold");

      });
     

    $(function(){
    $("div").addClass(function(index,currentCLass){
    	if(currentCLass===
    		"dummy"){
    		return "blue-box";
    	}
    });

    $(".blue-box").removeClass("blue-box").addClass("red-box");
  
     



    });

 /*$(function(){
    $(".blue-box").animate({
      "margin-right":"-=500px"
    },2000,"linear");
    });*/


 //$(".red-box").fadeIn(5000);
});


